### text recognitions ###


import sys
import re

### load the stop Words ###
print "loading the stop words list"
stop = open("stopWord.txt")
stop_list = []
for line in stop:
	words = line.strip()
	stop_list.append(words)

print "stop words list done"


### processing the data file ###
print "loading data file"
data = open("dummy5.txt")
reading =False

all_word_list = []

# deal with public
for line in data :
	if reading :
		info = line.split("\t")
		texted = info[text_index].strip()
		texted = re.sub("'", '', texted)
		text_list = texted.split()
		for text in text_list:
			if text in stop_list:
				continue
			else:
				all_word_list.append(text)


	if line.startswith("Response"):
		reading = True
		line = line.strip()
		info = line.split("\t")
		print info
		text_index = info.index("Text")

words_count_dic = {}
for text in all_word_list:
	if text not in words_count_dic.keys():
		words_count_dic[text] = all_word_list.count(text)


out_file = open("word_count.txt", 'w')
for word in words_count_dic.keys():
	num = words_count_dic.get(word)
	printed = "%s %s \n" %(word, num)
	out_file.write(printed)











