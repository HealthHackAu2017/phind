### graphing dynamic phd data ### 

# taking arguments [WORKING-DIR] [NAME] [TOPICS] [OUTPUT-GRAPH]
args <- commandArgs(TRUE)

TMPD <- args[1]
user <- args[2]
topic <- args[3]
out1 <- args[4]

### Load the the entire data frame ###
dummy = read.table("dummy5.txt", h=T, sep ="\t")
dummy$Date = as.Date(dummy$Date) # make sure the date col as a date

# check of unique individuals on database
unique(dummy$UserID)

# subset to individual only
indiv = dummy[dummy$UserID==user,]

# choose topic
stress_pub = dummy[dummy$Topic==topic,]
stress_pub$data = "public" #declare this a public
# averaging by date
unique_date = unique(stress_pub$Date)
date_avr_list = c()
for (i in unique_date) {
  dates = stress_pub[stress_pub$Date==i,]
  avr = mean(dates$Score)
  date_avr_list = c(date_avr_list, avr)
}
public <- data.frame(unique_date, date_avr_list)
names(public) = c("Date","Score")
public$data = "public"
head(public)

# subset to individual scores
you = indiv[indiv$Topic=="stress",]
you = you[,c("Date","Score")]
you$data = "you"

# combine public and individual for plotting
comp = rbind(public, you) 

# plotting using GGPLOT (line graphs comparison)
library("ggplot2")

myPlot = ggplot(data = comp, aes(x=Date, y=Score, colour=data))+ 
  geom_line() + ylim(0, 10)

ggsave(filename=out1, plot=myPlot)


