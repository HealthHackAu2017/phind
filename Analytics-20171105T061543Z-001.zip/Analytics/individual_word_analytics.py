### individuals  word count ###

import re

print "loading the stop words list"
stop = open("stopWord.txt")
stop_list = []
for line in stop:
	words = line.strip()
	stop_list.append(words)

print stop_list

print "stop words list done"

print "loading the danger words list"
danger = open("danger_words.txt")
danger_list = []
for line in danger:
	words = line.strip()
	danger_list.append(words)

print "danger words list done"

print "loading the danger words list"

### provide output container ###
out_file_text = open("output_all.txt", 'w')
out_file_danger = open("output_danger.txt", 'w')


### loading te data ###
print "loading data file"
data = open("dummy5.txt")
reading =False

for line in data :
	if reading:
		# loading line
		line = line.strip()
		info = line.split("\t")

		# picking the text column
		text = info[text_dex].strip()
		words_list = text.split()

		# remove stop words
		new_word_list = []
		for word in words_list :
			if word in stop_list :
				continue
			else :
				new_word_list.append(word)
			

		# report the key words
		new_word = ' '.join(new_word_list)
		new_line = line.strip() + '\t' + new_word + '\n'
		out_file_text.write(new_line)
	
		danger = []
		# detect danger words
		for word in new_word_list :
			if word in danger_list :
				danger.append(word)

		if len(danger) > 0 :
			score = info[score_dex]
			if int(score) > 7 :
				out_file_danger.write(new_line)		


	if line.startswith("Response"):
		reading = True
		# deal with col detections
		line = line.strip()
		info = line.split()
		text_dex = info.index("Text")
		score_dex = info.index("Score")

		# deal with out_files headers 
		header = "Response\tUserID\tDate\tTopic\tScore\tText\tWords\n" 
		out_file_text.write(header)








